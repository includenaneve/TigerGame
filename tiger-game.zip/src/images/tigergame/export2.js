export { default as play } from './play.png'
export { default as pause } from './pause.png'