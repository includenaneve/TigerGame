export { default as d1 } from './plant3D.png'
export { default as d3 } from './plant5D.png'
export { default as d4 } from './plant4D.png'
export { default as d5 } from './plant1D.png'