import React, { Component } from 'react'

import './Test.less'
export default class Test extends Component {
  render() {
    return (
      <div className="test">Test</div>
    )
  }
}