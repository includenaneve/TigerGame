import React from 'react'
import DefaultPage from '@components/DefaultPage/DefaultPage'

export default function Weixin(props) {
  return <DefaultPage text="请在微信客户端打开"/>
}
